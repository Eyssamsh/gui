<section class="app-screenshots section-padding" data-scroll-index="4" id="screenshots">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="section-title">
                    <h2>App <span>Screenshoots</span></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="owl-carousel screenshots-carousel">
                <div class="screenshot-item">
                    <img src="images/deutschfarbe.png" alt="Img App">
                </div>
                <div class="screenshot-item">
                    <img src="images/francaisneuefarbe.png" alt="Img App">
                </div>
                <div class="screenshot-item">
                    <img src="images/englischneuefarbe.png" alt="Img App">
                </div>
                <div class="screenshot-item">
                        <img src="images/deutsch.png" alt="Img App">
                </div>
                <div class="screenshot-item">
                        <img src="images/francaisneuefarbe.png" alt="Img App">
                </div>
                <div class="screenshot-item">
                        <img src="images/englischneuefarbe.png" alt="Img App">
                </div>
            </div>
        </div>
        
    </div>
</section>
