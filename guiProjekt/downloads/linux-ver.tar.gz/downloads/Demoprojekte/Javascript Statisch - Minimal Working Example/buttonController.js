
$('#langctrl_en').click(function(){
    UpdateLocalization("enus");
});

$('#langctrl_de').click(function(){
    UpdateLocalization("dede");
});
