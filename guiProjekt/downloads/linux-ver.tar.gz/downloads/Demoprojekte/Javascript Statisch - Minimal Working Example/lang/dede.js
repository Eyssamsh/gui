lang["dede"] = {
    title: "hallo",
    headline: "Ich bin eine Überschrift",
    bodytext: "Und ich bin der Text",
}
