lang["enus"] = {
    title: "hallo",
    headline: "I'm a headline",
    bodytext: "And i'm the text!",
}
